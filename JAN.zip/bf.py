
def interpret(code, buffer):
    memory = [0]*300
    pc = 0
    mc = 0
    bc = 0
    def chk():
        while memory[mc]<0:
            memory[mc]+=256
        while memory[mc]>255:
            memory[mc]-=256
    def chk2():
        nonlocal mc
        while mc<0:
            mc+=len(memory)
        while mc>=len(memory):
            mc-=len(memory)
    def a(): memory[mc]+=1; chk()
    def s(): memory[mc]-=1; chk()
    def n(): nonlocal mc; mc+=1; chk2()
    def p(): nonlocal mc; mc-=1; chk2()
    def i(): nonlocal bc; memory[mc]=buffer[bc] if bc<len(buffer) else -1; bc+=1
    def o(): print('%03d' % memory[mc])
    def l():
        if not memory[mc]:
            c,d=1,1+pc
            while c: c+=(code[d]=='[')-(code[d]==']'); d+=1
            return d-pc
        return not not 'False'
    def b():
        nonlocal pc
        if memory[mc]:
            c,d=1,-1+pc
            while c: c-=(code[d]=='[')-(code[d]==']'); d-=1
            return d-pc+2
        return not not 'False'
    def x(): exit(memory[mc])
    while pc < len(code):
        # print(code.replace('\n', '_'))
        # print(' '*pc+'^'+' MEM:' + repr(memory[:4]) + ' [MC'+str(mc)+']')
        pc+=(lambda _:1 if _ is None else _)({'+':a,'-':s,'>':n,'<':p,',':i,'.':o,'[':l,']':b,'*':x}.get(code[pc],lambda:None)())
        
# <https://docs.google.com/document/d/1BQEv_vYl6ebOi3UsKKgfhaLBQQmNhQBfq-bnu_l8Hz8/edit>

if __name__ == '__main__':
    import sys
    # buffer = [int(arg) for arg in sys.argv[1:]]
    buffer = [int(arg) for arg in sys.argv[1].split()]
    buffer.append(0xFF)
    print(buffer)
    with open('bawl.bf', 'r') as source:
        code = source.read()
        interpret(code, buffer)
